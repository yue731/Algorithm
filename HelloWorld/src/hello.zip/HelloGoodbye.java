public class HelloGoodbye {

    public static void main(String[] args) {
	// write your code here
        String nameA = args[0];
        String nameB = args[1];
        System.out.println("Hello " +  nameA + " and " + nameB + ".");
        System.out.println("Goodbye " + nameB + " and " + nameA + ".");
    }
}
